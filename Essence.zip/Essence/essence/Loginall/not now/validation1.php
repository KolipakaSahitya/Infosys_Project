<?php
 $connect=mysql_connect("localhost:1234","root","") or die("could not connect");
 $db=mysql_select_db("info",$connect) or die("could not select db");
 if(isset($_REQUEST["login"]))
 {
	if(isset($_REQUEST["username"]))
	{
		$un=$_REQUEST["username"];
	}
	else
	{
		echo "enter username";
	}
	
	if(isset($_REQUEST["password"]))
	{
		$pw=$_REQUEST["password"];
	}
	else
	{
		echo "enter password";
	}
	
	$val=mysql_query("select * from user");
	$flag=0;
	while(($row=mysql_fetch_array($val)) && $flag==0)
	{
		if($row["username"]==$_REQUEST["username"])
		{
			if($row["password"]==$_REQUEST["password"])
			{
				$flag=1;
				echo "wlcome $un";
			}
			else
			{
				echo "incorrect password";
			}
		}
		
	}
	if($flag==0)
	{
		echo "user doesn't exist,signup";
	}
	
 }
 if(isset($_REQUEST["signup"]))
 {
	if(isset($_REQUEST["username"]))
	{
		$un=$_REQUEST["username"];
	}
else
	{
		echo "enter username";
	}
	
	if(isset($_REQUEST["password"]))
	{
		$pw=$_REQUEST["password"];
	}
	else
	{
		echo "enter password";
	}
    
    $flag=0;
	$val=mysql_query("select * from user");
	while(($row=mysql_fetch_array($val)) && $flag==0)
	{
		if($row["username"]==$_REQUEST["username"])
		{
			echo "user already exist";
			$flag=1;
		}
		
	}
	if($flag==0)
	{
		$val1=mysql_query("insert into user values('".$un."','".$pw."');");
        echo "welcome $un,successfully signedup";	
	}		
 }
 mysql_close($connect);
?>
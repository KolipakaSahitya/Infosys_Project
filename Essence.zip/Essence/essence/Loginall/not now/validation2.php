<?php
$con=mysql_connect("localhost","root","");
$db=mysql_select_db("valid",$con) or die("could not select db");
if(isset($_REQUEST["login"]))
{
	
    if(isset($_REQUEST["username"]))
	{
		$un=$_REQUEST["username"];
	}
	else
	{
		echo "enter username";
	}
	if(isset($_REQUEST["password"]))
	{
		$ps=$_REQUEST["password"];
	}
	else
	{
		echo "enter password";
	}
	$q= "select * from student;";
	$val=mysql_query($q);
	while($row=mysql_fetch_array($val))
	{
		if($row['username']==$un)
		{
			
		       if($row["password"]==$ps)
			   {
				echo"welcome";
			   }
			   else
			   echo"wrong password";
		      
		}
		/*else
			echo "wrong username or wrong password";*/
	}
	
	//echo "please signup";
}
else
{
	if(isset($_REQUEST["login"]))
	{
		
		$us=$_REQUEST["username"];
		$ps=$_REQUEST["password"];
		$a="INSERT into student values ('$us','$ps');";
		mysql_query($a);
		 
		echo "signed up successfully";
		
	}
	
}
mysql_close($connect);
?>